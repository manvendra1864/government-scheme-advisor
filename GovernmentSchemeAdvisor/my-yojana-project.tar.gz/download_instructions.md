# How to Download Your My Yojana Project Files

## Method 1: Download Individual Files
1. In the Replit file explorer (left sidebar), click on any file to open it
2. Once the file is open, you can copy all content (Ctrl+A then Ctrl+C)
3. Create a new file on your computer and paste the content

## Method 2: Using Replit's Export Feature
1. Look for a "Share" button or menu in the top-right area of Replit
2. Check if there's an "Export" or "Download" option in the share menu
3. Some Replit versions have this under the repl settings

## Method 3: Using the Shell to Create a ZIP
1. Open the Shell tab in Replit (bottom of screen)
2. Run these commands to create a downloadable ZIP:
   ```bash
   zip -r my-yojana-project.zip . -x ".*" "__pycache__/*" "*.pyc"
   ```
3. This creates a ZIP file you can then download

## Method 4: Copy Files Manually (Most Reliable)
1. Open each file in Replit by clicking on it
2. Select all content (Ctrl+A / Cmd+A)
3. Copy (Ctrl+C / Cmd+C) 
4. Create new files on your local machine and paste the content

## Method 5: Using Git (Advanced)
1. If your repl has Git enabled, open the Shell tab
2. Run: `git archive --format=zip HEAD > my-yojana-project.zip`
3. This creates a ZIP of your project files

## Important Files to Download:
- `app.py` - Main Flask application
- `main.py` - Entry point
- `models.py` - Database models
- `routes.py` - URL routes
- `utils.py` - Helper functions
- `pyproject.toml` - Dependencies
- `templates/` folder - All HTML templates
- `static/` folder - CSS, JS, and schemes.json
- `replit.md` - Project documentation

## Running Locally After Download:
1. Install Python 3.11+
2. Install dependencies: `pip install flask flask-sqlalchemy gunicorn psycopg2-binary werkzeug email-validator sqlalchemy`
3. Set environment variable: `SESSION_SECRET=your-secret-key`
4. Run: `python app.py`
5. Open browser to `http://localhost:5000`